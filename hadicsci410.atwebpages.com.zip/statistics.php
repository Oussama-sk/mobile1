<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

$con = mysqli_connect("fdb1029.awardspace.net", "4564966_mobile", "TJ]lfW[D2,cq;g.U", "4564966_mobile");

if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}

// Fetch data from the database
$sql = "SELECT u.username, l.answer AS low_answer, c.answer AS color_answer 
        FROM user u,low l,color c,test t where u.id = t.userid and t.id = l.testid and t.id = c.testid ";

$result = mysqli_query($con, $sql);

$data = array();

if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }
    echo json_encode($data);
} else {
    echo json_encode(array('message' => 'No data found'));
}

mysqli_close($con);
?>
