<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Content-Type: text/html; charset=UTF-8");

$con = mysqli_connect("fdb1029.awardspace.net", "4564966_mobile", "TJ]lfW[D2,cq;g.U", "4564966_mobile");

if (mysqli_connect_errno()) {
    die("Failed to connect to MySQL: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if POST data is set
    if (isset($_POST['username']) && isset($_POST['password'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $sql = "SELECT * FROM user WHERE username = '$username'";
        $result = mysqli_query($con, $sql);

        if ($result) {
            $user = mysqli_fetch_assoc($result);

            if ($user && password_verify($password, $user['password'])) {
                echo "Login successful";
            } else {
                echo "Invalid username or password";
            }
        } else {
            echo "Error: " . mysqli_error($con);
        }
    } else {
        echo "Missing required POST data";
    }
} else {
    echo "Invalid request method";
}

mysqli_close($con);
?>
