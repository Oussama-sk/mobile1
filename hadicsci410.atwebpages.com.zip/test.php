<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $con = mysqli_connect("fdb1029.awardspace.net", "4564966_mobile", "TJ]lfW[D2,cq;g.U", "4564966_mobile");

    if (!$con) {
        exit("Failed to connect to MySQL: " . mysqli_connect_error());
    }

    $colorBlindnessCounter = $_POST['colorBlindnessCounter'];
    $lowVisionCounter = $_POST['lowVisionCounter'];
    $date = $_POST['date'];
    $username = $_POST['username'];

    if ($_POST['colorresult'] == 'true') {
        $colorresult = 1;
    } else {
        $colorresult = 0;
    }

    if ($_POST['lowresult'] == 'true') {
        $lowresult = 1;
    } else {
        $lowresult = 0;
    }

    $sql = "SELECT id FROM user WHERE username = '$username'";
    $result = mysqli_query($con, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $userid = mysqli_fetch_assoc($result)['id'];

        $sql = "INSERT INTO test (date, userid) VALUES ('$date', '$userid')";
        if (mysqli_query($con, $sql)) {
            $testid = mysqli_insert_id($con);

            $sql = "INSERT INTO low (passtest, answer, testid) VALUES ('$lowresult', '$lowVisionCounter', '$testid')";
            mysqli_query($con, $sql) ? 
                print "New record created successfully in low table<br>" : 
                print "Error in low table insert: " . mysqli_error($con) . "<br>";

            $sql = "INSERT INTO color (passtest, answer, testid) VALUES ('$colorresult', '$colorBlindnessCounter', '$testid')";
            mysqli_query($con, $sql) ? 
                print "New record created successfully in color table<br>" : 
                print "Error in color table insert: " . mysqli_error($con) . "<br>";
        } else {
            echo "Error in test table insert: " . mysqli_error($con) . "<br>";
        }
    } else {
        echo "Error: User not found";
    }
} else {
    echo "Not a POST request.\n";
}

if (isset($con)) {
    mysqli_close($con);
}
?>
